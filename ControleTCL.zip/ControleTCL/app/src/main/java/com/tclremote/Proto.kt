package com.tclremote

import java.io.*

class PbW {
    val o = ByteArrayOutputStream()
    fun varint(v: Long): PbW { var x = v; while ((x and -128L) != 0L) { o.write(((x and 127L) or 128L).toInt()); x = x ushr 7 }; o.write(x.toInt()); return this }
    fun int(f: Int, v: Int) = varint((f shl 3).toLong()).varint(v.toLong())
    fun bytes(f: Int, b: ByteArray): PbW { varint(((f shl 3) or 2).toLong()).varint(b.size.toLong()); o.write(b); return this }
    fun str(f: Int, s: String) = bytes(f, s.toByteArray())
    fun msg(f: Int, b: PbW.() -> Unit) = bytes(f, PbW().apply(b).o.toByteArray())
    fun done(): ByteArray = o.toByteArray()
}

fun frame(m: ByteArray): ByteArray = PbW().varint(m.size.toLong()).done() + m

fun readFrame(i: InputStream): ByteArray {
    var n = 0; var sh = 0
    while (true) { val b = i.read(); if (b < 0) throw EOFException(); n = n or ((b and 0x7F) shl sh); if ((b and 0x80) == 0) break; sh += 7 }
    val buf = ByteArray(n); var r = 0
    while (r < n) { val x = i.read(buf, r, n - r); if (x < 0) throw EOFException(); r += x }
    return buf
}

fun parse(b: ByteArray): Map<Int, Any> {
    val m = HashMap<Int, Any>(); var p = 0
    fun vi(): Long { var r = 0L; var s = 0; while (true) { val x = b[p++].toInt(); r = r or ((x and 0x7F).toLong() shl s); if ((x and 0x80) == 0) break; s += 7 }; return r }
    while (p < b.size) {
        val t = vi().toInt(); val f = t shr 3
        when (t and 7) {
            0 -> m[f] = vi()
            2 -> { val n = vi().toInt(); m[f] = b.copyOfRange(p, p + n); p += n }
            1 -> p += 8
            5 -> p += 4
            else -> return m
        }
    }
    return m
}
