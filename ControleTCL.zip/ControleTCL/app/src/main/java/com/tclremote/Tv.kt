package com.tclremote

import android.content.Context
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.math.BigInteger
import java.security.*
import java.security.interfaces.RSAPublicKey
import java.util.Date
import java.util.concurrent.Executors
import javax.net.ssl.*
import kotlin.concurrent.thread

val PASS = "tclremote".toCharArray()

/** Cria (uma vez) o certificado do app, que identifica o celular perante a TV. */
fun loadKeys(ctx: Context): KeyStore {
    val f = File(ctx.filesDir, "id.p12")
    val ks = KeyStore.getInstance("PKCS12")
    if (f.exists()) { f.inputStream().use { ks.load(it, PASS) }; return ks }
    val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
    val n = X500Name("CN=controle-tcl"); val now = System.currentTimeMillis()
    val cert = JcaX509CertificateConverter().getCertificate(
        JcaX509v3CertificateBuilder(n, BigInteger.valueOf(now), Date(now - 86400000L), Date(now + 3650L * 86400000L), n, kp.public)
            .build(JcaContentSignerBuilder("SHA256withRSA").build(kp.private)))
    ks.load(null, null); ks.setKeyEntry("k", kp.private, PASS, arrayOf(cert))
    f.outputStream().use { ks.store(it, PASS) }
    return ks
}

fun sslFor(ks: KeyStore): SSLContext {
    val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm()).apply { init(ks, PASS) }
    val tm = object : X509TrustManager {   // a TV usa certificado próprio, então aceitamos
        override fun checkClientTrusted(c: Array<java.security.cert.X509Certificate>, a: String) {}
        override fun checkServerTrusted(c: Array<java.security.cert.X509Certificate>, a: String) {}
        override fun getAcceptedIssuers() = arrayOf<java.security.cert.X509Certificate>()
    }
    return SSLContext.getInstance("TLS").apply { init(kmf.keyManagers, arrayOf<TrustManager>(tm), null) }
}

class Pairing(private val host: String, private val ks: KeyStore) {
    private lateinit var s: SSLSocket
    private fun send(f: PbW.() -> Unit) { s.outputStream.write(frame(PbW().int(1, 2).int(2, 200).apply(f).done())); s.outputStream.flush() }
    private fun recv() = readFrame(s.inputStream)

    fun start() {
        s = sslFor(ks).socketFactory.createSocket(host, 6467) as SSLSocket; s.startHandshake()
        send { msg(10) { str(1, "androidtv-remote"); str(2, "Controle TCL") } }; recv()
        send { msg(20) { msg(1) { int(1, 3); int(2, 6) }; int(3, 1) } }; recv()
        send { msg(30) { msg(1) { int(1, 3); int(2, 6) }; int(2, 1) } }; recv()
    }

    private fun hx(n: BigInteger): ByteArray { var h = n.toString(16); if (h.length % 2 == 1) h = "0$h"; return h.chunked(2).map { it.toInt(16).toByte() }.toByteArray() }

    fun finish(code: String): Boolean {
        val c = code.trim().uppercase(); if (c.length != 6) return false
        val mine = ks.getCertificate("k").publicKey as RSAPublicKey
        val tv = s.session.peerCertificates[0].publicKey as RSAPublicKey
        val md = MessageDigest.getInstance("SHA-256")
        md.update(hx(mine.modulus)); md.update(hx(mine.publicExponent)); md.update(hx(tv.modulus)); md.update(hx(tv.publicExponent))
        md.update(c.substring(2).chunked(2).map { it.toInt(16).toByte() }.toByteArray())
        val h = md.digest()
        if ((h[0].toInt() and 0xFF) != c.substring(0, 2).toInt(16)) return false
        send { msg(40) { bytes(1, h) } }
        val ok = parse(recv())[2] == 200L
        s.close(); return ok
    }
}

class Remote(private val host: String, private val ks: KeyStore, private val onState: (Boolean) -> Unit) {
    @Volatile private var s: SSLSocket? = null
    private val out = Executors.newSingleThreadExecutor()

    private fun send(b: ByteArray) = out.execute { try { s?.outputStream?.apply { write(frame(b)); flush() } } catch (_: Exception) {} }
    fun key(code: Int) = send(PbW().msg(10) { int(1, code); int(2, 3) }.done())
    fun openLink(url: String) = send(PbW().msg(90) { str(1, url) }.done())
    fun close() { try { s?.close() } catch (_: Exception) {} }

    fun start() = thread {
        try {
            val sock = sslFor(ks).socketFactory.createSocket(host, 6466) as SSLSocket
            sock.startHandshake(); s = sock
            while (true) {
                val m = parse(readFrame(sock.inputStream))
                when {
                    m.containsKey(1) -> send(PbW().msg(1) { int(1, 622); msg(2) { str(1, "TCL Remote"); str(2, "Android"); int(3, 1); str(4, "1"); str(5, "androidtv-remote"); str(6, "1.0.0") } }.done())
                    m.containsKey(2) -> { send(PbW().msg(2) { int(1, 622) }.done()); onState(true) }
                    m.containsKey(8) -> { val v = (parse(m[8] as ByteArray)[1] as? Long) ?: 0L; send(PbW().msg(9) { int(1, v.toInt()) }.done()) }
                }
            }
        } catch (_: Exception) { onState(false) }
    }
}
