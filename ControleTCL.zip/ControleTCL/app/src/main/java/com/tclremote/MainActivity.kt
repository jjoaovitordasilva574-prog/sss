package com.tclremote

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.security.KeyStore
import kotlin.concurrent.thread

class Ctl(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("tv", Context.MODE_PRIVATE)
    private val ks: KeyStore by lazy { loadKeys(ctx) }
    var host by mutableStateOf(prefs.getString("host", "") ?: "")
    var screen by mutableStateOf(if (host.isEmpty()) "connect" else "remote")
    var online by mutableStateOf(false)
    var status by mutableStateOf("")
    val found = mutableStateListOf<Pair<String, String>>()
    private var remote: Remote? = null
    private var pairing: Pairing? = null

    init { if (host.isNotEmpty()) io { connect() } }

    private fun io(f: () -> Unit) = thread { try { f() } catch (e: Exception) { status = "Erro: ${e.message}"; if (screen != "remote") screen = "connect" } }

    fun startPair(h: String) { host = h; screen = "wait"; io { val p = Pairing(h, ks); p.start(); pairing = p; screen = "code" } }
    fun submit(code: String) = io { if (pairing?.finish(code) == true) { prefs.edit().putString("host", host).apply(); connect() } else status = "Código incorreto, tente de novo" }
    fun connect() { remote?.close(); remote = Remote(host, ks) { online = it }.also { it.start() }; screen = "remote" }
    fun key(code: Int) { remote?.key(code) }
    fun app(url: String) { remote?.openLink(url) }
    fun forget() { remote?.close(); prefs.edit().remove("host").apply(); host = ""; online = false; screen = "connect" }

    fun scan() {
        found.clear()
        val nsd = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
        nsd.discoverServices("_androidtvremote2._tcp", NsdManager.PROTOCOL_DNS_SD, object : NsdManager.DiscoveryListener {
            override fun onServiceFound(i: NsdServiceInfo) {
                nsd.resolveService(i, object : NsdManager.ResolveListener {
                    override fun onServiceResolved(r: NsdServiceInfo) { r.host?.hostAddress?.let { a -> if (found.none { it.second == a }) found.add(r.serviceName to a) } }
                    override fun onResolveFailed(i: NsdServiceInfo, e: Int) {}
                })
            }
            override fun onStartDiscoveryFailed(t: String, e: Int) {}
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
            override fun onDiscoveryStarted(t: String) {}
            override fun onDiscoveryStopped(t: String) {}
            override fun onServiceLost(i: NsdServiceInfo) {}
        })
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val c = Ctl(applicationContext)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFE53935), background = Color(0xFF0E0F13), surface = Color(0xFF1A1C22))) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    when (c.screen) {
                        "connect" -> Connect(c)
                        "wait" -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Conectando à TV…", color = Color.White) }
                        "code" -> Code(c)
                        else -> RemoteUi(c)
                    }
                }
            }
        }
    }
}

@Composable fun Connect(c: Ctl) {
    var ip by remember { mutableStateOf("") }
    LaunchedEffect(Unit) { c.scan() }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Controle TCL", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text("Escolha sua TV (celular e TV no mesmo Wi‑Fi)", color = Color.Gray)
        c.found.forEach { (n, h) -> Button(onClick = { c.startPair(h) }, Modifier.fillMaxWidth()) { Text("$n  •  $h") } }
        OutlinedTextField(ip, { ip = it }, label = { Text("Ou digite o IP da TV") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Button(onClick = { if (ip.isNotBlank()) c.startPair(ip.trim()) }, Modifier.fillMaxWidth()) { Text("Conectar") }
        Text(c.status, color = Color.Gray)
    }
}

@Composable fun Code(c: Ctl) {
    var t by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("Digite o código que apareceu na TV", fontSize = 18.sp, color = Color.White)
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(t, { t = it.uppercase().take(6) }, singleLine = true, textStyle = TextStyle(fontSize = 28.sp, letterSpacing = 6.sp, textAlign = TextAlign.Center))
        Spacer(Modifier.height(16.dp))
        Button(onClick = { c.submit(t) }, enabled = t.length == 6) { Text("Parear") }
        Text(c.status, color = Color.Gray)
    }
}

@Composable fun RemoteUi(c: Ctl) {
    val h = LocalHapticFeedback.current
    fun k(code: Int) { h.performHapticFeedback(HapticFeedbackType.LongPress); c.key(code) }
    val card = Color(0xFF1A1C22)
    @Composable fun Round(label: String, code: Int) = Box(Modifier.size(76.dp).clip(CircleShape).background(card).clickable { k(code) }, Alignment.Center) { Text(label, color = Color.White, fontSize = 13.sp) }
    @Composable fun Arrow(g: String, m: Modifier, code: Int) = Box(m.size(70.dp).clip(CircleShape).clickable { k(code) }, Alignment.Center) { Text(g, color = Color.White, fontSize = 26.sp) }
    @Composable fun Pill(title: String, up: Int, down: Int) = Column(Modifier.width(80.dp).clip(RoundedCornerShape(40.dp)).background(card), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.fillMaxWidth().height(72.dp).clickable { k(up) }, Alignment.Center) { Text("+", color = Color.White, fontSize = 28.sp) }
        Text(title, color = Color.Gray, fontSize = 12.sp)
        Box(Modifier.fillMaxWidth().height(72.dp).clickable { k(down) }, Alignment.Center) { Text("−", color = Color.White, fontSize = 28.sp) }
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(22.dp)) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(if (c.online) "● Conectada" else "● Desconectada", color = if (c.online) Color(0xFF4CAF50) else Color.Gray)
            Row { TextButton(onClick = { k(26) }) { Text("Ligar/Desligar") }; TextButton(onClick = { c.forget() }) { Text("Trocar TV") } }
        }
        Box(Modifier.size(280.dp).clip(CircleShape).background(card), Alignment.Center) {
            Arrow("▲", Modifier.align(Alignment.TopCenter), 19); Arrow("▼", Modifier.align(Alignment.BottomCenter), 20)
            Arrow("◀", Modifier.align(Alignment.CenterStart), 21); Arrow("▶", Modifier.align(Alignment.CenterEnd), 22)
            Box(Modifier.size(104.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary).clickable { k(23) }, Alignment.Center) { Text("OK", fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Color.White) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) { Round("Voltar", 4); Round("Home", 3); Round("Menu", 82) }
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly, Alignment.CenterVertically) { Pill("VOL", 24, 25); Round("Mudo", 164); Pill("CANAL", 166, 167) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("YouTube" to "https://www.youtube.com", "Netflix" to "https://www.netflix.com", "Prime" to "https://app.primevideo.com", "Disney+" to "https://www.disneyplus.com").forEach { (n, u) ->
                AssistChip(onClick = { c.app(u) }, label = { Text(n) })
            }
        }
    }
}
